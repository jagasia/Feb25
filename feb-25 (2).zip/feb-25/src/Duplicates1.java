import java.util.HashSet;
import java.util.Set;

public class Duplicates1 {

	public static void main(String[] args) {
		Set<Integer> marks=new HashSet<Integer>();
		marks.add(10);
		marks.add(11);
		marks.add(2);
		marks.add(33);
		marks.add(10);
		marks.add(10);
		marks.add(2);
		marks.add(22);
		marks.add(33);
		System.out.println(marks);
		//Set is a collection of distinct objects
	}

}
