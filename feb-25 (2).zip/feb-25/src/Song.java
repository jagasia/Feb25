import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Song {
	private String title;
	private String genre;
	private Date duration;
	private Double rating;
	public Song()
	{}
	public Song(String title, String genre, Date duration, Double rating) {
		super();
		this.title = title;
		this.genre = genre;
		this.duration = duration;
		this.rating = rating;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Date getDuration() {
		return duration;
	}
	public void setDuration(Date duration) {
		this.duration = duration;
	}
	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	static Song createSong(String  line) throws ParseException
	{
		String[] arr = line.split(",");
		Song song=new Song();
		song.setTitle(arr[0]);
		song.setGenre(arr[1]);
		SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");
		song.setDuration(sdf.parse(arr[2]));
		song.setRating(Double.valueOf(arr[3]));
		return song;
	}
}
