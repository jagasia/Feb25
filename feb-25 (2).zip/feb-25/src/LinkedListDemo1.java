import java.util.LinkedList;

public class LinkedListDemo1 {

	public static void main(String[] args) {
		LinkedList<Integer> marks=new LinkedList<>();
		marks.add(100);
		marks.add(50);
		marks.add(78);
		marks.add(2);
		marks.add(78);
		marks.add(25);
		marks.add(11);
		marks.add(200);
		System.out.println(marks);
	}

}
