import java.text.ParseException;
import java.util.Scanner;

public class Main_Mobile2 {
	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		MobileBrand mobileBrand=new MobileBrand();
		System.out.println("Enter the name of the Mobile Brand:");
		String name=sc.nextLine();
		mobileBrand.setName(name);
		do
		{
			System.out.println("1.Add Mobile\r\n" + 
					"2.Delete Mobile\r\n" + 
					"3.Display Mobiles\r\n" + 
					"4.Exit\r\n" + 
					"Enter your choice:\r\n" + 
					"");

			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:			//add
				String detail=sc.nextLine();
				if(detail.equals(""))
					detail=sc.nextLine();
				Mobile mobile = Mobile.createMobile(detail);
				mobileBrand.addMobileToMobileBrand(mobile);
				break;
			case 2:			//delete
				System.out.println("Enter the reference id of the mobile to be deleted:");
				String referenceId=sc.nextLine();
				if(referenceId.equals(""))
					referenceId=sc.nextLine();
				if(mobileBrand.removeMobileFromMobileBrand(referenceId))
					System.out.println("Mobile successfully deleted");
				else
					System.out.println("Mobile not found in the Mobile Brand");
				break;
			case 3:			//display
				mobileBrand.displayMobiles();
				break;
			case 4:
				System.exit(0);
			}
		}while(true);
	}
}
