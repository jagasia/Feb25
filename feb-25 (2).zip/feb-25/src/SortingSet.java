import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SortingSet {

	
	public static void main(String[] args) {
		Set<Integer> marks=new HashSet<>();
		marks.add(12);
		marks.add(1);
		marks.add(15);
		marks.add(8);
		marks.add(3);
		marks.add(5);
		marks.add(2);
		
		//Collections.sort will not work for Set. It works only for List
		//so convert set into List and sort
//		List<Integer> dummy=new ArrayList<Integer>(marks);
		List<Integer> dummy=new ArrayList<Integer>();
		dummy.addAll(marks);
		Collections.sort(dummy);
		marks.clear(); 			//remove all
		marks.addAll(dummy);
		System.out.println(marks);
	}

}
