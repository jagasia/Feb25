import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Set;
import java.util.TreeSet;

public class MobileTree {

	public static void main(String[] args) throws ParseException {
		Set<Mobile> mobileSet=new TreeSet<>((a,b)->b.getReferenceId().compareTo(a.getReferenceId()));
//		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

		mobileSet.add(new Mobile("B", "K20", 5.6, 25000.0, "21-12-2019"));
		mobileSet.add(new Mobile("A", "Samsung", 5.5, 12000.0, "21-01-2019"));
		mobileSet.add(new Mobile("K", "LG", 4.6, 10000.0, "31-12-2018"));
		mobileSet.add(new Mobile("E", "Nokia", 5.6, 25000.0, "11-11-2017"));
		mobileSet.add(new Mobile("R", "Realme", 6.6, 25000.0, "08-12-2020"));
		mobileSet.add(new Mobile("Y", "Lava", 5.6, 22000.0, "09-10-2018"));
		
		for(Mobile m:mobileSet)
			System.out.println(m);
	}

}
