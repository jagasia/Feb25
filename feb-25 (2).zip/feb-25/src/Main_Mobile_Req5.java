import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main_Mobile_Req5 {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of mobiles:");
		int n=sc.nextInt();
		List<Mobile> mobileList=new ArrayList<Mobile>();
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			Mobile mobile = Mobile.createMobile(detail);
			mobileList.add(mobile);
		}
		System.out.println("Enter a type to sort:\r\n" + 
				"1.Sort by price\r\n" + 
				"2.Sort by launched date\r\n" + 
				"");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:			//sort by price		Mobile class itself has logic
			Collections.sort(mobileList);
			break;
		case 2:			//sort by launched date			comparator is used
			LaunchedDateComparator c=new LaunchedDateComparator();
			Collections.sort(mobileList,c);
			break;
		}
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");

		System.out.format("%-15s %-15s %-12s %-8s %s\n","Reference Id","Model Name","Display Size","Price","Launched Date");
		for(Mobile m:mobileList)
			System.out.format("%-15s %-15s %-12s %-8s %s\n",m.getReferenceId(),m.getModelName(),m.getDisplaySize(),m.getPrice(),sdf.format(m.getLaunchedDate()));
	
	
	}

}
