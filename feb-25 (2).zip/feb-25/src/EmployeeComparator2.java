import java.util.Comparator;

public class EmployeeComparator2 implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		if(o1.getFirstName().equals(o2.getFirstName()))
			return o2.getLastName().compareTo(o1.getLastName());
		return o1.getFirstName().compareTo(o2.getFirstName());
	}

}
