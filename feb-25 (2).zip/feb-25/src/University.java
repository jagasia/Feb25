import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class University {
	private String name;
	private List<College> collegeList;
	public University() 
	{
		collegeList=new ArrayList<College>();
	}
	public University(String name, List<College> collegeList) {
		this();
		this.name = name;
		this.collegeList = collegeList;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<College> getCollegeList() {
		return collegeList;
	}
	public void setCollegeList(List<College> collegeList) {
		this.collegeList = collegeList;
	}
	public void addCollegeToUniversity(College college)
	{
		this.collegeList.add(college);
		System.out.println("College successfully added");
	}
	public Boolean removeCollege(String name)
	{
		//find college from the collegeList using its name
		College college=null;
		for(College c:collegeList)
		{
			if(c.getName().equals(name))
			{
				//college is found. this college only we need to remove
				//while looping a collection, we cannot remove an element. That will cause ConcurrentModificationException
				college=c;		//store the reference of this found college in a variable
			}
		}
		//check if a college is found in that given name
		if(college!=null)
		{
			//remove
			collegeList.remove(college);
			return true;
		}
		return false;
	}
	public void displayColleges()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		if(collegeList.size()==0)
			System.out.println("No colleges to show");
		else
		{
			System.out.format("%-15s%-20s%-15s%-15s%-15s%-15s%-15s\n", "Name","Website","Mobile","Founder","Number of Dept","Location","Starting Date");
			for(College c : collegeList)
			{
				System.out.format("%-15s%-20s%-15s%-15s%-15s%-15s%-15s\n", c.getName(),c.getWebsite(),c.getMobile(),c.getFounder(),c.getNumberOfDept(),c.getLocation(),sdf.format(c.getStartingDate()));
			}
		}
	}

}
