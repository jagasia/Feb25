import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;

public class Main_LinkedHashSet {

	public static List<Integer> removeDuplicates(List<Integer> input)
	{
		LinkedHashSet<Integer> x=new LinkedHashSet<>(input);
		List<Integer> result=new ArrayList<>(x);
		return result;
	}
	
	public static void main(String[] args) {
		List<Integer> input=Arrays.asList(1,2,8,2,8,1,7,3,5,4);
		List<Integer> result = removeDuplicates(input);
		System.out.println(result);
		
	}

}
