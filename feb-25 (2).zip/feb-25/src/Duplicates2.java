import java.util.HashSet;
import java.util.Set;

public class Duplicates2 {

	public static void main(String[] args) {
		Set<Employee> empSet=new HashSet<>();
		empSet.add(new Employee(12,"Zaheer","Hussain",125000.0));
		empSet.add(new Employee(7,"Suresh","Raina",185000.0));
		empSet.add(new Employee(22,"Muruga","Prasad",115000.0));
		empSet.add(new Employee(52,"Dinesh","Srinivasan",150000.0));
		empSet.add(new Employee(33,"Rama","Rajan",135000.0));
		empSet.add(new Employee(33,"Suresh","Peters",135000.0));
		empSet.add(new Employee(33,"Abdul","Rahman",135000.0));
		empSet.add(new Employee(33,"Muruga","Anand",135000.0));
		empSet.add(new Employee(33,"Zaheer","Khan",135000.0));
		empSet.add(new Employee(33,"Rama","Rajan",135000.0));
		
		for(Employee e:empSet)
			System.out.println(e);
	}

}
