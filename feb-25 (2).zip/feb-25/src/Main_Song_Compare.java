import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main_Song_Compare {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of songs:");
		int n=sc.nextInt();
		List<Song> songList=new ArrayList<Song>();
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			Song song=Song.createSong(detail);
			songList.add(song);
		}
		System.out.println("Enter a type to sort: \r\n" + 
				"1.Sort by Duration \r\n" + 
				"2.Sort by Rating \r\n" + 
				"");
	
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:		//sort by duration
			break;
		case 2:		//sort by rating
			break;
			
		}
		SimpleDateFormat sdf=new SimpleDateFormat("mm:ss");
		System.out.format("%-20s %-10s %-12s %-12s\n","Title","Genre","Duration","Rating");
		for(Song s : songList)
			System.out.format("%-20s %-10s %-12s %-12s\n",s.getTitle(),s.getGenre(),sdf.format(s.getDuration()),s.getRating());
	}

}
