
public class ParamArray1 {

	public static void display(int ...arr)
	{
		for(int a:arr)
			System.out.println(a);
	}
	public static void main(String[] args) {
		int x[]= {11,2,3,44,32,23,12,21};
		display(x);
		display(2,3,100,40,32);		//allowed in param array
	}

}
