import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo1 {

	public static void main(String[] args) {
		ArrayList<Integer> marks=new ArrayList<>();
		marks.add(100);
		marks.add(50);
		marks.add(78);
		marks.add(2);
		marks.add(78);
		marks.add(25);
		marks.add(11);
		marks.add(200);
		marks.add(0, 1000);
		System.out.println(marks);
	}

}
