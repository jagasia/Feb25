import java.util.Comparator;

public class EmployeeFirstNameComparator implements Comparator<Employee>
{

	@Override
	public int compare(Employee arg0, Employee arg1) {
		//arg0 compare to arg1		is asc order		vice versa is desc order
		return arg0.getFirstName().compareTo(arg1.getFirstName());
	}

}
