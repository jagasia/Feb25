
public class Employee implements Comparable<Employee> {
	private Integer employeeId;
	private String firstName;
	private String lastName;
	private Double salary;
	public Employee() {}
	public Employee(Integer employeeId, String firstName, String lastName, Double salary) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + "]";
	}
	@Override
	public int compareTo(Employee o) {
		// how to compare two employees(as you suggested, we will compare by salary)
		//look at the return type of this method		int
		//if they are same, return 0		if a is greater than b then return positive else negative
		//salary is Double (D caps)	and hence it has compareTo method.	Every pre defined class has compareTo method
		//string has compareTo method. 		Date has compareTo method		if we used double primitive 
		//then to compare primitives, we use - symbol and then cast double result to int
		return o.getSalary().compareTo(this.getSalary());
	}
	
}

//	a-b		returns positive means,		a is bigger than b
//	a-b		returns negative means,		a is smaller than b

