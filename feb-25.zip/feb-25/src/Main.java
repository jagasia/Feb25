import java.text.ParseException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws ParseException {
		University university=new University();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of the University: ");
		String universityName=sc.nextLine();
		university.setName(universityName);
		
		do
		{
			System.out.println("1.Add College \r\n" + 
					"2.Delete College \r\n" + 
					"3.Display Colleges \r\n" + 
					"4.Exit \r\n" + 
					"Enter your choice: ");
			
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:			//add			
				String detail=sc.nextLine();
				if(detail.equals(""))
					detail=sc.nextLine();
				//how to create a college object from a csv string???
				College college = College.createCollege(detail);
				university.addCollegeToUniversity(college);
				break;
			case 2:			//delete
				System.out.println("Enter the name of the college to be deleted:");
				String collegeName=sc.nextLine();
				if(collegeName.equals(""))
					collegeName=sc.nextLine();
				//using the college name, how to delete a college from university?????
				if(university.removeCollege(collegeName))
					System.out.println("College successfully deleted");
				else					
					System.out.println("College not found in the University");
				break;
			case 3:			//display
				university.displayColleges();
				break;	
			case 4:
				System.exit(0);
			}
		}while(true);
			
	}
}
