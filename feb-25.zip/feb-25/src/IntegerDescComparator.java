import java.util.Comparator;

public class IntegerDescComparator implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
		// TODO Auto-generated method stub
		return o2.compareTo(o1);				//desc o2-o1
	}

}
