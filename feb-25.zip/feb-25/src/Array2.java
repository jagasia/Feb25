import java.util.Arrays;

public class Array2 {

	public static void main(String[] args) {
//		int a;			//this is enough
//		Employee e;		//this is not complete object
//		e=new Employee();	//only then it is an object
		Employee arr[]=new Employee[10];
		arr[0]=new Employee(12,"Zaheer","Hussain",125000.0);
		arr[1]=new Employee(7,"Suresh","Raina",185000.0);
		arr[2]=new Employee(22,"Muruga","Prasad",115000.0);
		arr[3]=new Employee(52,"Dinesh","Srinivasan",150000.0);
		arr[4]=new Employee(33,"Rama","Rajan",135000.0);
		arr[5]=new Employee(33,"Suresh","Peters",135000.0);
		arr[6]=new Employee(33,"Abdul","Rahman",135000.0);
		arr[7]=new Employee(33,"Muruga","Anand",135000.0);
		arr[8]=new Employee(33,"Zaheer","Khan",135000.0);
		arr[9]=new Employee(33,"Abdul","Kalam",135000.0);
		
//		Arrays.sort(arr);
//		Arrays.sort(arr,new EmployeeFirstNameComparator());
//		Arrays.sort(arr,new EmployeeComparator2());
		Arrays.sort(arr,(x,y)->y.getFirstName().compareTo(x.getFirstName()));
		
		for(Employee x:arr)
			System.out.println(x);

	}

}
