import java.util.Arrays;
import java.util.Comparator;

public class Array1 {

	public static void main(String[] args) {
		Integer arr[]= {4,2,6,5,7,1,10,2,33,22};
//		Arrays.sort(arr);							//we are able to sort any array using Arrays.sort(arr);
//		Arrays.sort(arr,new IntegerDescComparator());
		Arrays.sort(arr, (x,y)->y-x);
		System.out.println(Arrays.toString(arr));
	}

}
