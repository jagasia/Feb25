import java.util.HashSet;

public class HashSetDemo1 {

	public static void main(String[] args) {
		HashSet<Integer> marks=new HashSet<>();
		marks.add(100);
		marks.add(50);
		marks.add(78);
		marks.add(2);
		marks.add(78);
		marks.add(25);
		marks.add(11);
		marks.add(200);
		System.out.println(marks);
	}

}
